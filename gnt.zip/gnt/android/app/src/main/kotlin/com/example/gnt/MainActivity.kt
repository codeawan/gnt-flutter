package com.example.gnt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
